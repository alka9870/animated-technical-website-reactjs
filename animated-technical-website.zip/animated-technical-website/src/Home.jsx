import React from "react"; 
import web from "../src/images/webdevelopment.svg";
import { Link } from "react-router-dom";
import Common from "./Common";
const Home = () =>{
    return (
        <>
            <Common name = "Grow your business with" imgsrc={web} visit="/contact" btnname="Get Start"/>
        </>
    );
};

export default Home;