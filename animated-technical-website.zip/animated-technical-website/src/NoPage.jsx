import React from "react"; 

const NoPage = () =>{
    return (
        <>
            <h1>Opps!</h1>
        </>
    );
};

export default NoPage;