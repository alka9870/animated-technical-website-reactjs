import React from "react";

const Footer = () =>{
    return (
    <>
        <footer className="bg-light text-center bg-body-tertiary">
           <p>@2024 Technical Website | All Rights reserved | Terms and conditions</p>
        </footer>
    </>
    );
};

export default Footer;