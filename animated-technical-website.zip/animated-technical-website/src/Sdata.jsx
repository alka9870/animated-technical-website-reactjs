
import web from "../src/images/wd.jpg";
import app from "../src/images/app.png";
import android from "../src/images/sd.jpg";
import digital from "../src/images/digi.png";
import marketing from "../src/images/dgg.jpg";
import software from "../src/images/se.jpg";

const Sdata = [
    {
        imgsrc: web,
        title:"Web Development",
    },
    {
        imgsrc:app,
        title:"App Development",
    },
    {
        imgsrc:android,
        title:"Software Development",
    },
    {
        imgsrc:digital,
        title:"Digital Development",
    },
    {
        imgsrc:marketing,
        title:"Digital Marketing",
    },
    {
        imgsrc:software,
        title:"Software Engineer",
    },

]

export default Sdata;