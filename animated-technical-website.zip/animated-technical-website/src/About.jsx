import React from "react"; 
import web from "../src/images/homeim.svg";
import { Link } from "react-router-dom";
import Common from "./Common";

const About = () =>{
    return (
        <>
          <Common name = "Welcome to about page" imgsrc={web} visit="/contact" btnname="Contact Now"/>
        </>
    );
};

export default About;